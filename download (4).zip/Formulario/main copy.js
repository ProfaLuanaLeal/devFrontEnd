// declarando as variaveis de conexão html
const notaform=document.getElementById('notaform');
const notaInput=document.getElementById('notaInput');
const dataInput=document.getElementById('dataInput');
const listaNotas=document.getElementById('listaNotas');

//Função para carregar as notas do localStorage
function carregarNotas(){
    const notas=JSON.parse(localStorage.getItem('notas')) || [];
    listaNotas.innerHTML='';
    notas.forEach(({texto,data,hora}) => {
        const divNota=document.createElement('div');
        divNota.className='nota';
        divNota.innerHTML=`${texto}<div class="data-hora">${data} ${hora}</div>`;
        listaNotas.appendChild(divNota);   
    });
}    
//adicionar uma nova nota
notaform.addEventListener('submit',function(event){
    event.preventDefault();
    const novaNota=notaInput.value
    const data=dataInput.value;
    const hora=new Date().toLocaleTimeString('pt-BR',{hour12:false});
    const notas=JSON.parse(localStorage.getItem('notas')) || [];
    notas.push({texto:novaNota,data,hora});
    localStorage.setItem('notas',JSON.stringify(notas));

    //ALOC MEMORY
    notaInput.value='';
    dataInput.value=''; 

    carregarNotas();
});

//iniciar
document.addEventListener('DOMContentLoaded',carregarNotas);